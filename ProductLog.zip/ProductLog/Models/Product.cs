namespace ProductLog.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Product
    {
        public int ProductID { get; set; }

        [StringLength(64)]
        [Display(Name ="Product Name")]
        public string ProductName { get; set; }
        [Display(Name = "Product Description")]
        public string ProductDescription { get; set; }

        [StringLength(255)]
        [Display(Name = "Product Price")]
        public string ProductPrice { get; set; }

        public int? StockOnHand { get; set;} 
    }
}
