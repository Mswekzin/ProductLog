﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using ProductLog.Models;

namespace ProductLog.Controllers
{
    public class ProductsController : Controller
    {
        private OrderDirectDbContext db = new OrderDirectDbContext();

        public ActionResult Index()
        {
            return View(db.Product.ToList());
        }

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "ProductID,ProductName,ProductDescription,ProductPrice,StockOnHand")] Product product)
        {
            if (ModelState.IsValid)
            {
                Random rnd = new Random();
                product.StockOnHand = rnd.Next(1, 100);
                db.Product.Add(product);
                db.SaveChanges();
                ViewBag.message = "Product Saved Successfully";


                return View(product);
                //return RedirectToAction("Index");
            }
            ViewBag.message = "There was a problem adding this product.";
            return View(product);
        }

        [HttpGet]
        public JsonResult Delete(int id)
        {
            try
            {
                Product product = db.Product.Find(id);
                db.Product.Remove(product);
                db.SaveChanges();
            }
            catch
            {
            }
            return Json(new object[] { new object() }, JsonRequestBehavior.AllowGet);
        }
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
